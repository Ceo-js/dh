var express = require('express');
var router = express.Router();
var controller = require('../controllers/indexController')
const {body, check} = require('express-validator')

/* GET home page. */
router.get('/', controller.index);
router.post('/',[
    check('name').isLength({min:1}).withMessage('Você deve digitar um nome'),
    check('email').isEmail().withMessage('Você deve digitar um endereço de e-mail válido'),
    check('color').isLength({min:1}).withMessage('Você deve selecionar um color'),
    body('age').custom(value => {
        if(isNaN(value)){
            throw new Error('O valor inserido deve ser um número');
        }else {
            return true;
        }
    })

], controller.store);

router.get('/color', controller.color)
router.get('/apagar', controller.apagar)

module.exports = router;
